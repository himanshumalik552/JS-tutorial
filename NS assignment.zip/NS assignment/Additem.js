// Add element in array in last

let arr = [2, 4, 5, 7, 3];
arr.push(5);
console.log(arr);
