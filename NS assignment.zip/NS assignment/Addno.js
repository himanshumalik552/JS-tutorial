//Add two numbers

let Add = (a, b) => {
    console.log(a+b);
}
Add(4,6);