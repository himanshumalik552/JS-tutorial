// Add element any where specify position

let arr = [2, 5, 3, 7, 4, 2];
let index = 3;
let element = 99;
arr.splice(index, 0 , element);
console.log(arr);